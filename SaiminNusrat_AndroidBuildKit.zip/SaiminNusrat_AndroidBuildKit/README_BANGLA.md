# SAIMIN & NUSRAT — Android APK Build Kit

এটি Android APK তৈরির জন্য একটি ছোট native Android WebView wrapper project। এতে আগের playable HTML prototype অ্যাপের ভিতরে bundled আছে। এটি এখনো GTA-স্টাইল 3D Unity game নয়।

## শুধু Android ফোন দিয়ে APK বানানোর পথ (GitHub Actions)

এই প্যাকেজে APK নেই। GitHub Actions-এর cloud runner-এ build করাতে হবে।

1. GitHub-এ লগইন করে নতুন **public বা private repository** তৈরি করো, যেমন `saimin-nusrat-love-story`।
2. এই ZIP ফাইলটি এবং আলাদা দেওয়া `build-apk.yml` ফাইলটি repository-তে upload করো।
3. `build-apk.yml`-কে repository-তে এই path-এ রাখো: `.github/workflows/build-apk.yml`। GitHub website-এ **Add file → Create new file** করে filename হিসেবে পুরো path লিখে YAML content paste করা যায়।
4. Repository-এর **Actions** tab খুলে `Build SAIMIN & NUSRAT Android APK` workflow-তে ঢুকে **Run workflow** চাপো। যদি Actions নিষ্ক্রিয় থাকে, enable করো।
5. কাজ সফল হলে workflow run-এর নিচের **Artifacts** অংশ থেকে `SaiminNusrat-debug-apk` download করো। ZIP extract করে `app-debug.apk` ফোনে tap করো। Android-এ “Install unknown apps” অনুমতি চাইতে পারে; শুধু নিজের তৈরি artifact ইনস্টল করো।
6. Build fail হলে Actions-এর error log-এ প্রথম `FAILURE` বা `What went wrong` অংশ দেখো।

## Build details
- Android application ID: `com.saiminnusrat.lovestory`
- Landscape orientation, fullscreen
- Minimum Android API: 23 (Android 6.0)
- Debug APK; release signing configured নয়
- GitHub Actions runner-এ Java 17, Gradle 8.9, Android SDK, Android Gradle Plugin 8.7.3 ব্যবহার হয়

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- বর্তমান গেমটি 2D top-down HTML prototype; 3D Unity game নয়।
- APK size 150 MB হবে বলে দাবি করা হচ্ছে না। প্রকৃত art, 3D character/environment models, animations, music ও sound effects যোগ না হওয়া পর্যন্ত APK ছোট হবে। কেবল 150 MB করার জন্য অপ্রয়োজনীয় padding যোগ করা হয়নি।
- এই পরিবেশে APK compile/install test করা হয়নি। GitHub Actions build সফল হওয়া এবং বাস্তব ফোনে install/play test করা আলাদা বিষয়।
